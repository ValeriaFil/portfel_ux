---
name: valeria-fil-portfolio-design
description: Use this skill to generate well-branded interfaces and assets for the Valeria Filipchyk UX/UI designer portfolio brand, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files (tokens,
components, ui_kits, guidelines, assets).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create
static HTML files for the user to view. If working on production code, you can copy assets and read
the rules here to become an expert in designing with this brand.

Key starting points:
- `styles.css` — the single global stylesheet (tokens + fonts + base).
- `readme.md` — content fundamentals, visual foundations, iconography.
- `components/core/` — reusable React primitives (`*.prompt.md` shows usage).

If the user invokes this skill without any other guidance, ask them what they want to build or
design, ask a few clarifying questions, and act as an expert designer who outputs HTML artifacts
_or_ production code, depending on the need. Match the brand: white canvas, one vivid accent per
section, Rubik UPPERCASE display headings + Roboto body, soft `2px 2px 20px` card shadows, 10px card
radius, full-pill magenta→pink gradient buttons, subtle ease-out motion, and no emoji.
