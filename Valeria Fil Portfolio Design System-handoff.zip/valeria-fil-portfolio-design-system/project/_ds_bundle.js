/* @ds-bundle: {"format":3,"namespace":"ValeriaFilPortfolioDesignSystem_fba7d6","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Callout","sourcePath":"components/core/Callout.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"FlowStep","sourcePath":"components/core/FlowStep.jsx"},{"name":"FlowArrow","sourcePath":"components/core/FlowStep.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconBadge","sourcePath":"components/core/IconBadge.jsx"},{"name":"ProjectCard","sourcePath":"components/core/ProjectCard.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"SocialIcon","sourcePath":"components/core/SocialIcon.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"0cf1d42b5a67","components/core/Button.jsx":"fad017a0fc8c","components/core/Callout.jsx":"a020d1ba40a8","components/core/Card.jsx":"41277d73ebba","components/core/FlowStep.jsx":"56bc5d8d7545","components/core/Icon.jsx":"ea9b52e37b49","components/core/IconBadge.jsx":"619022ecfb65","components/core/ProjectCard.jsx":"b010882c3d25","components/core/SectionHeading.jsx":"81fc12a3cd59","components/core/SocialIcon.jsx":"8005e9e058a1","components/core/Tag.jsx":"f07d1bdc2c81"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ValeriaFilPortfolioDesignSystem_fba7d6 = window.ValeriaFilPortfolioDesignSystem_fba7d6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Avatar — circular portrait. Falls back to the brand placeholder grey when
 * no src is given (matching the empty avatar discs in the layout).
 */
function Avatar({
  src,
  alt = '',
  size = 240,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: size,
      height: size,
      borderRadius: 'var(--radius-full)',
      overflow: 'hidden',
      background: src ? `center / cover no-repeat url(${src})` : 'var(--color-placeholder)',
      flexShrink: 0,
      ...style
    },
    role: "img",
    "aria-label": alt
  }, rest));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — the portfolio's pill action. Signature variant is the magenta→pink
 * gradient with white Poppins label; outline is a pink-bordered ghost.
 */
function Button({
  children = 'Contact',
  variant = 'primary',
  // 'primary' | 'outline' | 'ghost'
  size = 'md',
  // 'sm' | 'md' | 'lg'
  as = 'button',
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '12px 28px',
      fontSize: 15
    },
    md: {
      padding: '16px 38px',
      fontSize: 17
    },
    lg: {
      padding: '21px 42px',
      fontSize: 18
    }
  };
  const variants = {
    primary: {
      background: 'var(--gradient-pink)',
      color: 'var(--color-white)',
      border: 'none'
    },
    outline: {
      background: 'transparent',
      color: 'var(--color-pink)',
      border: '1px solid var(--color-pink)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--color-ink)',
      border: '1px solid var(--color-line)'
    }
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: "vf-button",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      fontFamily: 'var(--font-button)',
      fontWeight: 600,
      lineHeight: 1.25,
      borderRadius: 'var(--radius-pill)',
      cursor: 'pointer',
      textDecoration: 'none',
      whiteSpace: 'nowrap',
      transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), opacity var(--dur-fast) var(--ease-out)',
      ...sizes[size],
      ...variants[variant],
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.transform = 'var(--motion-lift)';
      if (variant === 'primary') e.currentTarget.style.boxShadow = '0 8px 22px 0 rgba(253,21,86,0.30)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'none';
      e.currentTarget.style.boxShadow = 'none';
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the white, gently-rounded surface with the soft diffuse shadow that
 * underpins nearly every block in the portfolio. Hover lifts it slightly.
 */
function Card({
  children,
  padding = 'var(--pad-card-lg)',
  hover = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-card)',
      padding,
      transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)',
      ...style
    },
    onMouseEnter: hover ? e => {
      e.currentTarget.style.transform = 'var(--motion-lift)';
      e.currentTarget.style.boxShadow = 'var(--shadow-hover)';
    } : undefined,
    onMouseLeave: hover ? e => {
      e.currentTarget.style.transform = 'none';
      e.currentTarget.style.boxShadow = 'var(--shadow-card)';
    } : undefined
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/FlowStep.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * FlowStep — a pink-outlined pill used in case-study flow diagrams
 * ("Browse rooms → Check details → …"). Pair with FlowArrow between steps.
 */
function FlowStep({
  children,
  active = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 22px',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--color-pink)',
      background: active ? 'var(--color-surface-pink)' : 'transparent',
      color: 'var(--color-ink)',
      fontFamily: 'var(--font-body)',
      fontWeight: 500,
      fontSize: 'var(--fs-body)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), children);
}

/** FlowArrow — the thin "→" connector between flow steps. */
function FlowArrow({
  style = {}
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-ink)',
      fontSize: 18,
      lineHeight: 1,
      ...style
    }
  }, "\u2192");
}
Object.assign(__ds_scope, { FlowStep, FlowArrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/FlowStep.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Icon — the portfolio's small inline SVG glyph set.
 * All paths use currentColor so the icon takes its parent's color.
 * Extracted from the Figma file (clip, clock, arrow); linkedin / mail / user
 * are matched generic glyphs at the same 18–24px optical weight.
 */
const PATHS = {
  clip: {
    vb: '0 0 18 17.041',
    d: 'M 16.804 2.554 C 16.031 1.781 15.004 1.356 13.911 1.356 C 12.819 1.356 11.791 1.781 11.019 2.554 L 4.57 9.002 C 3.613 9.959 3.613 11.516 4.57 12.473 C 5.527 13.43 7.084 13.43 8.041 12.473 L 12.287 8.227 C 12.607 7.908 12.607 7.39 12.287 7.07 C 11.968 6.751 11.45 6.751 11.13 7.07 L 6.884 11.316 C 6.565 11.635 6.046 11.635 5.727 11.316 C 5.408 10.997 5.408 10.478 5.727 10.159 L 12.176 3.711 C 12.639 3.247 13.256 2.992 13.911 2.992 C 14.567 2.992 15.183 3.247 15.647 3.711 C 16.604 4.668 16.604 6.225 15.647 7.182 L 8.62 14.209 C 7.025 15.804 4.429 15.804 2.835 14.209 C 2.062 13.436 1.636 12.409 1.636 11.316 C 1.636 10.224 2.062 9.196 2.835 8.424 L 9.861 1.397 C 10.181 1.077 10.181 0.559 9.861 0.24 C 9.542 -0.08 9.024 -0.08 8.704 0.24 L 1.677 7.267 C 0.596 8.348 0 9.787 0 11.316 C 0 12.846 0.596 14.284 1.677 15.366 C 2.794 16.483 4.26 17.041 5.727 17.041 C 7.194 17.041 8.66 16.482 9.777 15.366 L 16.804 8.339 C 18.399 6.744 18.399 4.149 16.804 2.554 Z'
  },
  clock: {
    vb: '0 0 18 18',
    d: 'M 9 18 C 13.969 18 18 13.969 18 9 C 18 4.031 13.969 0 9 0 C 4.031 0 0 4.031 0 9 C 0 13.969 4.031 18 9 18 Z M 8.357 3.857 C 8.357 3.504 8.646 3.214 9 3.214 C 9.354 3.214 9.643 3.504 9.643 3.857 L 9.643 8.691 L 12.616 11.07 C 12.893 11.292 12.938 11.697 12.716 11.973 C 12.59 12.131 12.404 12.214 12.214 12.214 C 12.073 12.214 11.931 12.169 11.813 12.073 L 8.598 9.501 C 8.447 9.379 8.357 9.196 8.357 9 L 8.357 3.857 L 8.357 3.857 Z'
  },
  user: {
    vb: '0 0 18 18',
    d: 'M 9 9.2 C 11.04 9.2 12.69 7.55 12.69 5.5 C 12.69 3.45 11.04 1.8 9 1.8 C 6.96 1.8 5.31 3.45 5.31 5.5 C 5.31 7.55 6.96 9.2 9 9.2 Z M 9 10.8 C 5.6 10.8 1.8 12.55 1.8 15.5 L 1.8 16.2 L 16.2 16.2 L 16.2 15.5 C 16.2 12.55 12.4 10.8 9 10.8 Z'
  },
  linkedin: {
    vb: '0 0 24 24',
    d: 'M4.98 3.5C4.98 4.88 3.87 6 2.49 6C1.12 6 0 4.88 0 3.5C0 2.12 1.12 1 2.49 1C3.87 1 4.98 2.12 4.98 3.5ZM5 8H0V24H5V8ZM12.98 8H8.01V24H12.98V15.6C12.98 11.1 18.85 10.73 18.85 15.6V24H23.84V13.88C23.84 6.09 14.92 6.37 12.98 10.2V8Z'
  },
  mail: {
    vb: '0 0 24 24',
    d: 'M20 4H4C2.9 4 2.01 4.9 2.01 6L2 18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 8L12 13L4 8V6L12 11L20 6V8Z'
  }
};
function Icon({
  name = 'clip',
  size = 18,
  color = 'currentColor',
  strokeArrow,
  style = {},
  ...rest
}) {
  if (name === 'arrow') {
    // Composite: circle outline head + arrow shaft, matching the Figma "arrow 1"
    return /*#__PURE__*/React.createElement("svg", _extends({
      width: size,
      height: size,
      viewBox: "0 0 32 32",
      fill: color,
      style: {
        display: 'block',
        ...style
      },
      "aria-hidden": "true"
    }, rest), /*#__PURE__*/React.createElement("g", {
      transform: "translate(4 2)"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M 20.091 4.101 C 18.791 2.801 17.247 1.769 15.549 1.066 C 13.85 0.362 12.029 0 10.191 0 C 8.352 0 6.532 0.362 4.833 1.066 C 3.134 1.769 1.591 2.801 0.291 4.101 C 0.105 4.288 0 4.542 0 4.806 C 0 5.07 0.105 5.324 0.291 5.511 C 0.478 5.697 0.732 5.802 0.996 5.802 C 1.26 5.802 1.513 5.697 1.701 5.511 C 3.381 3.837 5.519 2.698 7.846 2.239 C 10.172 1.779 12.583 2.019 14.773 2.928 C 16.963 3.838 18.835 5.376 20.152 7.348 C 21.469 9.321 22.171 11.639 22.171 14.011 C 22.171 16.383 21.469 18.701 20.152 20.674 C 18.835 22.646 16.963 24.184 14.773 25.094 C 12.583 26.003 10.172 26.243 7.846 25.783 C 5.519 25.324 3.381 24.185 1.701 22.511 C 1.513 22.325 1.26 22.22 0.996 22.22 C 0.732 22.22 0.478 22.325 0.291 22.511 C 0.105 22.698 0 22.952 0 23.216 C 0 23.48 0.105 23.734 0.291 23.921 C 2.919 26.547 6.483 28.021 10.198 28.019 C 12.037 28.018 13.859 27.655 15.558 26.95 C 17.257 26.245 18.801 25.212 20.101 23.911 C 21.401 22.61 22.432 21.065 23.135 19.365 C 23.838 17.665 24.2 15.843 24.199 14.004 C 24.198 12.164 23.834 10.343 23.13 8.644 C 22.425 6.945 21.392 5.401 20.091 4.101 Z"
    }), /*#__PURE__*/React.createElement("path", {
      transform: "translate(2 8)",
      d: "M 11.79 10.294 C 11.696 10.387 11.622 10.498 11.571 10.62 C 11.52 10.741 11.494 10.872 11.494 11.004 C 11.494 11.136 11.52 11.267 11.571 11.389 C 11.622 11.511 11.696 11.621 11.79 11.714 C 11.883 11.808 11.994 11.882 12.115 11.933 C 12.237 11.984 12.368 12.01 12.5 12.01 C 12.632 12.01 12.763 11.984 12.885 11.933 C 13.006 11.882 13.117 11.808 13.21 11.714 L 18.21 6.714 C 18.304 6.621 18.378 6.511 18.429 6.389 C 18.48 6.267 18.506 6.136 18.506 6.004 C 18.506 5.872 18.48 5.741 18.429 5.62 C 18.378 5.498 18.304 5.387 18.21 5.294 L 13.21 0.294 C 13.022 0.106 12.766 0 12.5 0 C 12.234 0 11.978 0.106 11.79 0.294 C 11.602 0.482 11.496 0.738 11.496 1.004 C 11.496 1.27 11.602 1.526 11.79 1.714 L 15.09 5.004 L 1 5.004 C 0.735 5.004 0.48 5.109 0.293 5.297 C 0.105 5.485 0 5.739 0 6.004 C 0 6.269 0.105 6.524 0.293 6.711 C 0.48 6.899 0.735 7.004 1 7.004 L 15.09 7.004 L 11.79 10.294 Z"
    })));
  }
  const g = PATHS[name] || PATHS.clip;
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: g.vb,
    fill: color,
    style: {
      display: 'block',
      ...style
    },
    "aria-hidden": "true"
  }, rest), /*#__PURE__*/React.createElement("path", {
    d: g.d,
    fillRule: "nonzero"
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconBadge — the 32px magenta→pink gradient disc holding a white glyph.
 * Used beside callouts (clip), career rows (clock, user) and accents.
 */
function IconBadge({
  name = 'clip',
  size = 32,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      borderRadius: 'var(--radius-full)',
      background: 'var(--gradient-pink)',
      color: 'var(--color-white)',
      flexShrink: 0,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: name,
    size: Math.round(size * 0.56),
    color: "var(--color-white)"
  }));
}
Object.assign(__ds_scope, { IconBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconBadge.jsx", error: String((e && e.message) || e) }); }

// components/core/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Callout — a paperclip-badge + paragraph row, the recurring "note" pattern
 * in case-study intros. The pink gradient clip badge sits left of the text.
 */
function Callout({
  children,
  name = 'clip',
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 16,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.IconBadge, {
    name: name,
    size: 32,
    style: {
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-body)',
      lineHeight: 1.5,
      color: 'var(--color-ink)',
      maxWidth: 380
    }
  }, children));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Callout.jsx", error: String((e && e.message) || e) }); }

// components/core/ProjectCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ProjectCard — a thumbnail-in-a-white-card with a centered caption beneath,
 * exactly as the "Recent projects" row renders. Hover lifts the card.
 */
function ProjectCard({
  image,
  title,
  href = '#',
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 26,
      textDecoration: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "vf-projectcard-media",
    style: {
      width: '100%',
      aspectRatio: '349 / 198',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-card)',
      padding: 22,
      transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)'
    },
    onMouseEnter: e => {
      e.currentTarget.style.transform = 'var(--motion-lift)';
      e.currentTarget.style.boxShadow = 'var(--shadow-hover)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'none';
      e.currentTarget.style.boxShadow = 'var(--shadow-card)';
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      borderRadius: 4,
      background: image ? `center / cover no-repeat url(${image})` : 'var(--color-placeholder)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 'var(--fs-subtitle)',
      color: 'var(--color-ink)',
      textAlign: 'center'
    }
  }, title));
}
Object.assign(__ds_scope, { ProjectCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ProjectCard.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SectionHeading — the big uppercase Rubik display heading that opens each
 * portfolio section. Color is the per-section accent (blue, green, purple…).
 */
function SectionHeading({
  children,
  color = 'var(--color-green)',
  size = 'm',
  // 'xl' | 'l' | 'm'
  align = 'center',
  weight = 700,
  style = {},
  ...rest
}) {
  const sizes = {
    xl: 'var(--fs-display-xl)',
    l: 'var(--fs-display-l)',
    m: 'var(--fs-display-m)'
  };
  return /*#__PURE__*/React.createElement("h2", _extends({
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: weight,
      fontSize: sizes[size] || sizes.m,
      lineHeight: 1.2,
      textTransform: 'uppercase',
      textAlign: align,
      color,
      margin: 0,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/core/SocialIcon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SocialIcon — circular social link (LinkedIn / Mail) in the brand link-blue,
 * as seen under the name card on the landing page.
 */
function SocialIcon({
  name = 'linkedin',
  href = '#',
  size = 32,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    "aria-label": name,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      borderRadius: 'var(--radius-full)',
      background: 'var(--color-blue-link)',
      color: 'var(--color-white)',
      textDecoration: 'none',
      transition: 'transform var(--dur-base) var(--ease-out), opacity var(--dur-fast) var(--ease-out)',
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.transform = 'var(--motion-lift)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'none';
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: name,
    size: Math.round(size * 0.5),
    color: "var(--color-white)"
  }));
}
Object.assign(__ds_scope, { SocialIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SocialIcon.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Tag — a hashtag-style skill label. Plain accent-colored text (no chip),
 * matching the "#Prototyping #GameDesign" rows in the career section.
 * Set chip to render a soft pink pill instead.
 */
function Tag({
  children,
  color = 'var(--color-green)',
  chip = false,
  style = {},
  ...rest
}) {
  const base = {
    fontFamily: 'var(--font-body)',
    fontWeight: 400,
    fontSize: 'var(--fs-body)',
    lineHeight: 1.4,
    whiteSpace: 'nowrap'
  };
  if (chip) {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        ...base,
        display: 'inline-flex',
        alignItems: 'center',
        padding: '6px 14px',
        borderRadius: 'var(--radius-pill)',
        background: 'var(--color-surface-pink)',
        color: 'var(--color-pink-deep)',
        fontWeight: 500,
        ...style
      }
    }, rest), children);
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      color,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.FlowStep = __ds_scope.FlowStep;

__ds_ns.FlowArrow = __ds_scope.FlowArrow;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconBadge = __ds_scope.IconBadge;

__ds_ns.ProjectCard = __ds_scope.ProjectCard;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.SocialIcon = __ds_scope.SocialIcon;

__ds_ns.Tag = __ds_scope.Tag;

})();
