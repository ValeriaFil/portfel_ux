import React from 'react';

export interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Image URL; omit for the grey placeholder. */
  src?: string;
  alt?: string;
  /** Diameter in px. @default 240 */
  size?: number;
}

/** Circular portrait with brand-grey placeholder fallback. */
export function Avatar(props: AvatarProps): JSX.Element;
