One-sentence: Circular portrait with brand-grey placeholder fallback.

```jsx
<Avatar src="/path.png" size={240} />
<Avatar size={240} /> {/* grey placeholder */}
```
