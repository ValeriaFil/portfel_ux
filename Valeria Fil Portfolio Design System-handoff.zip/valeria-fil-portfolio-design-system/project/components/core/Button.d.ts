import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** Visual style. @default 'primary' */
  variant?: 'primary' | 'outline' | 'ghost';
  /** @default 'md' */
  size?: 'sm' | 'md' | 'lg';
  /** Element/tag to render (e.g. 'a'). @default 'button' */
  as?: any;
}

/**
 * Pill action button. Primary is the brand magenta→pink gradient.
 * @startingPoint section="Core" subtitle="Pill button — gradient / outline" viewport="420x180"
 */
export function Button(props: ButtonProps): JSX.Element;
