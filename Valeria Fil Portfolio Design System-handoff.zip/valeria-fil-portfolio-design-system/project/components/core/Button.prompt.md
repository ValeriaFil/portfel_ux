One-sentence: The portfolio's pill action button — magenta→pink gradient (primary), pink outline, or neutral ghost.

```jsx
<Button variant="primary" size="lg" onClick={...}>Contact</Button>
<Button variant="outline">Explore <Icon name="arrow" size={18} color="var(--color-pink)" /></Button>
```

Variants: primary | outline | ghost. Sizes: sm | md | lg. Pass `as="a"` + `href` for links.
