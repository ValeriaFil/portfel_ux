import React from 'react';
import { IconName } from './Icon';

export interface CalloutProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** Badge glyph. @default 'clip' */
  name?: IconName;
}

/** Paperclip-badge + paragraph "note" row used in case-study intros. */
export function Callout(props: CalloutProps): JSX.Element;
