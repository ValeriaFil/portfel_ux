One-sentence: Paperclip-badge + paragraph "note" row used in case-study intros.

```jsx
<Callout>Booking private rooms is inconvenient due to unclear availability.</Callout>
```

name changes the badge glyph (default clip).
