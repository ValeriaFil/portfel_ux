import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** CSS padding. @default 40px */
  padding?: string;
  /** Lift + deepen shadow on hover. @default false */
  hover?: boolean;
}

/**
 * White rounded surface with the signature soft card shadow.
 * @startingPoint section="Core" subtitle="White surface with soft shadow" viewport="420x220"
 */
export function Card(props: CardProps): JSX.Element;
