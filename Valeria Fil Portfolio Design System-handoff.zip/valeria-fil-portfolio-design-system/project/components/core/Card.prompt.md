One-sentence: White, 10px-rounded surface with the signature soft diffuse shadow.

```jsx
<Card padding="40px" hover>…</Card>
```

hover lifts + deepens the shadow. Default padding 40px.
