import React from 'react';

export interface FlowStepProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** Fill with soft pink to mark the current step. @default false */
  active?: boolean;
}

/** Pink-outlined pill for case-study flow diagrams. */
export function FlowStep(props: FlowStepProps): JSX.Element;

/** Thin arrow connector placed between FlowStep pills. */
export function FlowArrow(props: { style?: React.CSSProperties }): JSX.Element;
