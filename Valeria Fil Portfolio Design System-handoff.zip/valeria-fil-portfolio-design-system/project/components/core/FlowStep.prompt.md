One-sentence: Pink-outlined pill for case-study flow diagrams, with FlowArrow connectors.

```jsx
<FlowStep active>Browse rooms</FlowStep>
<FlowArrow />
<FlowStep>Check details</FlowStep>
```

active fills with soft pink to mark the current step.
