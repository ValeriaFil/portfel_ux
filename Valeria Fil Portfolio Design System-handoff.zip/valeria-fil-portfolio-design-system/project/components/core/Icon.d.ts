import React from 'react';

export type IconName = 'clip' | 'clock' | 'user' | 'arrow' | 'linkedin' | 'mail';

export interface IconProps extends React.SVGProps<SVGSVGElement> {
  /** Which glyph to render. @default 'clip' */
  name?: IconName;
  /** Pixel size (width & height). @default 18 */
  size?: number;
  /** Fill color; defaults to currentColor so it inherits text color. */
  color?: string;
}

/** Inline SVG glyph set for the portfolio (clip, clock, user, arrow, linkedin, mail). */
export function Icon(props: IconProps): JSX.Element;
