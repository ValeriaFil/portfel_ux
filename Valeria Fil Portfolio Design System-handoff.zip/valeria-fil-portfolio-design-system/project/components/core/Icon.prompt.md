One-sentence: Inline SVG glyph set (clip, clock, user, arrow, linkedin, mail) using currentColor.

```jsx
<Icon name="clock" size={18} color="var(--color-pink)" />
```

Use inside IconBadge/SocialIcon or inline beside text. color defaults to currentColor.
