import React from 'react';
import { IconName } from './Icon';

export interface IconBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Glyph to show inside the gradient disc. @default 'clip' */
  name?: IconName;
  /** Disc diameter in px. @default 32 */
  size?: number;
}

/** Magenta→pink gradient circular badge wrapping a white Icon. */
export function IconBadge(props: IconBadgeProps): JSX.Element;
