One-sentence: 32px magenta→pink gradient disc holding a white glyph — used by callouts and career rows.

```jsx
<IconBadge name="clip" size={32} />
```

name accepts any Icon glyph. size scales the inner glyph automatically.
