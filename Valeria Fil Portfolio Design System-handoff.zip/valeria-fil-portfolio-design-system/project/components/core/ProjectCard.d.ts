import React from 'react';

export interface ProjectCardProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  /** Thumbnail image URL. */
  image?: string;
  /** Caption shown beneath the card. */
  title?: string;
  href?: string;
}

/**
 * Thumbnail card + centered caption, as in the "Recent projects" row.
 * @startingPoint section="Content" subtitle="Project thumbnail + caption" viewport="380x300"
 */
export function ProjectCard(props: ProjectCardProps): JSX.Element;
