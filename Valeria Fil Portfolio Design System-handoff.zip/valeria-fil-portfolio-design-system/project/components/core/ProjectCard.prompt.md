One-sentence: Thumbnail-in-a-white-card with centered caption, as in the Recent Projects row.

```jsx
<ProjectCard image="/thumb.png" title="Web platform «ABBA»" href="#" />
```

Card lifts on hover. Image fills a 349:198 frame.
