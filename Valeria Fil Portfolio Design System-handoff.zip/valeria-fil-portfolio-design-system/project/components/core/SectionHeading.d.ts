import React from 'react';

export interface SectionHeadingProps extends React.HTMLAttributes<HTMLHeadingElement> {
  children?: React.ReactNode;
  /** Per-section accent color. @default green */
  color?: string;
  /** Display scale. @default 'm' (48px) */
  size?: 'xl' | 'l' | 'm';
  align?: 'left' | 'center' | 'right';
  /** Font weight 600/700/800. @default 700 */
  weight?: number;
}

/** Big uppercase Rubik display heading that opens each portfolio section. */
export function SectionHeading(props: SectionHeadingProps): JSX.Element;
