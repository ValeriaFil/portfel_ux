import React from 'react';

/**
 * SectionHeading — the big uppercase Rubik display heading that opens each
 * portfolio section. Color is the per-section accent (blue, green, purple…).
 */
export function SectionHeading({
  children,
  color = 'var(--color-green)',
  size = 'm',         // 'xl' | 'l' | 'm'
  align = 'center',
  weight = 700,
  style = {},
  ...rest
}) {
  const sizes = { xl: 'var(--fs-display-xl)', l: 'var(--fs-display-l)', m: 'var(--fs-display-m)' };
  return (
    <h2
      style={{
        fontFamily: 'var(--font-display)',
        fontWeight: weight,
        fontSize: sizes[size] || sizes.m,
        lineHeight: 1.2,
        textTransform: 'uppercase',
        textAlign: align,
        color,
        margin: 0,
        ...style,
      }}
      {...rest}
    >
      {children}
    </h2>
  );
}
