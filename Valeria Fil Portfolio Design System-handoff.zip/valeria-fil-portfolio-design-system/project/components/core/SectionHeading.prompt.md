One-sentence: Big uppercase Rubik display heading opening each section, in the per-section accent color.

```jsx
<SectionHeading size="l" color="var(--color-blue-deep)">Recent projects</SectionHeading>
```

size: xl | l | m. weight: 600/700/800. Always renders UPPERCASE.
