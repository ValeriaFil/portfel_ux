import React from 'react';

export interface SocialIconProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  /** @default 'linkedin' */
  name?: 'linkedin' | 'mail';
  href?: string;
  /** Diameter in px. @default 32 */
  size?: number;
}

/** Circular blue social link button (LinkedIn / Mail). */
export function SocialIcon(props: SocialIconProps): JSX.Element;
