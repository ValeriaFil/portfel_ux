One-sentence: Circular blue social link (LinkedIn / Mail) from the name card.

```jsx
<SocialIcon name="linkedin" href="https://linkedin.com/in/..." />
```

name: linkedin | mail. Lifts on hover.
