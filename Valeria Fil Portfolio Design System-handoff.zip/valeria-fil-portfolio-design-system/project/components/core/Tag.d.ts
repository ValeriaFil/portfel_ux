import React from 'react';

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** Text color for the plain (non-chip) variant. @default green */
  color?: string;
  /** Render a soft pink pill instead of plain text. @default false */
  chip?: boolean;
}

/** Hashtag-style skill label — plain accent text or soft pink pill. */
export function Tag(props: TagProps): JSX.Element;
