One-sentence: Hashtag-style skill label — plain accent text, or a soft pink pill with chip.

```jsx
<Tag color="var(--color-green)">#Prototyping</Tag>
<Tag chip>#Collaboration</Tag>
```

Default renders plain colored text (no chip); set chip for the pink pill.
