# Valeria Fil Portfolio Design System

The design foundation for **Valeria Filipchyk's** personal portfolio website (Version 2) — a
UX/UI designer's self-branding site. The system favours **visual clarity, generous white
space, refined typography and subtle motion** over decoration. It is sized for a personal
branding portfolio, not a large product, so the component set is deliberately small and the
voice is first-person and personal.

> **Source of truth:** the attached Figma file **"porf-site (1).fig"** (page *Page-2*, 34
> frames — landing `main`, project gallery `Portfolio`, and case studies such as
> `Mini-Case Task «MovieNest»`, `Izobistar`, `Effectify`, `LumoControl`, `iFactory3D`,
> `Medi`). All tokens, components and icons here were extracted from that file. The reader
> is not assumed to have access; this note is for traceability.

---

## Index / manifest

| Path | What |
|------|------|
| `styles.css` | Global entry point — import this one file. `@import`s all tokens + base. |
| `tokens/` | `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `base.css` |
| `components/core/` | Reusable primitives (see below) — `.jsx` + `.d.ts` + `.prompt.md` + card HTML |
| `guidelines/` | Foundation specimen cards (Colors, Type, Spacing, Brand) for the Design System tab |
| `assets/` | `icons/` (extracted SVGs), `img/` (portrait, project thumbnails) |
| `SKILL.md` | Agent-Skill manifest for use in Claude Code |

**Components:** `Button`, `Icon`, `IconBadge`, `SocialIcon`, `Tag`, `Card`, `FlowStep` (+`FlowArrow`),
`SectionHeading`, `Avatar`, `ProjectCard`, `Callout`. All exported on
`window.ValeriaFilPortfolioDesignSystem_fba7d6`.

---

## CONTENT FUNDAMENTALS

**Voice — first person, warm and grounded.** Valeria speaks as *"I"* and addresses the reader
plainly. Copy is confident but not boastful, practical rather than poetic. Example:
*"For me, design is not just about visuals — it's first and foremost about functionality, logic,
and accessibility."* Case-study notes are reflective: *"Instead of redesigning the full app, I
focused on this exact moment where users hesitate."*

**Casing.** Section headings and the hero role are **UPPERCASE** display type
(`UX/UI DESIGNER`, `RECENT PROJECTS`, `CAREER`, `ABOUT`). Body copy is sentence case. Job titles
and card titles are Title Case. Skills are written as **hashtags** — `#Prototyping`,
`#GameDesign`, `#WebDesign`, `#Collaboration` — concatenated CamelCase, no spaces.

**Punctuation & style.** Uses em dashes and the «guillemets» around product names
(`Web platform «ABBA»`, `Booking app «MovieNest»`) — a Eurocentric convention, keep it.
Bulleted achievements start with a leading `•` and an action verb (*Designed, Collaborated,
Optimized, Led, Created*). Dates are parenthesised: `(2022 — Present)`, `(Jan 2021 — Dec 2022)`.

**No emoji.** The brand never uses emoji. Iconography is handled by the inline SVG glyph set and
the pink gradient badges. Numbers/stats are used sparingly and only when concrete (years of
experience, prices, capacities) — avoid invented metrics.

**Vibe.** Calm, structured, senior. Lets white space and a single vivid accent per section do the
talking. Reads like a thoughtful product designer, not a flashy agency.

---

## VISUAL FOUNDATIONS

**Canvas.** Pure white (`#FFFFFF`) everywhere. No full-bleed photography, no gradients-as-
background, no textures or patterns. Content lives in a centered **1149px column** with roomy
~147px side margins at 1440px. The page breathes — **100px** between major sections.

**Color.** The signature is a single **magenta→pink vertical gradient**
(`#BF154C → #FD1556`) reserved for the highest-signal moments: the primary pill button, the
circular icon badges (paperclip/clock/user), and case-study callout markers. Beyond that, **each
section owns one vivid heading accent** over the white canvas: sky blue `#009EE7` (hero role),
deep blue `#0068A4` (Recent Projects), forest green `#034C3B` (Career, About, job titles, skill
tags), electric purple `#6400E7` (UX/UI Projects label). Text is near-black `#0F0E0E`; meta is
`#808080`. Social links are a calmer link-blue `#0277B5`. The palette is bright and optimistic but
controlled — never more than one accent active per section.

**Type.** Two families do the work. **Rubik** carries every heading — *SemiBold (600)* for card
and job titles, *Bold (700)* for section headers, *ExtraBold (800)* for the big hero role — almost
always UPPERCASE with tight 1.0–1.2 line-height. **Roboto** carries all body copy and meta
(*Regular 400*, *Medium 500*) at 14–18px with 1.4–1.6 line-height. **Poppins SemiBold** is reserved
for the pill button label only. Scale: 84 / 64 / 48 (display) · 24 (title) · 18 (subtitle) ·
16 / 14 (body) · 12 (caption).

**Cards.** White, **10px** corner radius, **no border**, and one soft diffuse shadow —
`2px 2px 20px rgba(10,10,10,0.10)`. That shadow is the single most repeated visual signature.
Inner padding 26–40px (career cards pad 40×60). Cards never use colored left-borders or heavy
outlines.

**Corner radii.** 10px (cards, inputs, media), 16px (icon badges), full circle (avatars, social,
gradient badges), and a **112px pill** for buttons, flow-step chips and tags.

**Buttons.** Full-pill, gradient-filled, white Poppins label, generous 21×42 padding. Secondary
buttons are pink-outlined ghosts. Flow-diagram steps reuse the pill shape with a 1px pink outline.

**Imagery.** Project thumbnails sit *inside* a white shadowed card (image inset with ~22px
padding), with a centered Rubik caption beneath. Imagery is shown as-is (each project keeps its own
brand colors — ABBA red, MovieNest dark+gold, Izobistar coral). The portrait is a clean circular
crop. Empty media states use the placeholder grey `#D9D9D9` disc.

**Motion.** Subtle and intentional — short ease-out fades and a small **−3px lift** with a slightly
deeper shadow on card/button hover. No bounce, no parallax, no infinite loops. Durations 140–360ms,
ease `cubic-bezier(0.22,0.61,0.36,1)`. Press states keep it minimal.

**Transparency / blur.** Essentially unused. Tinted panels (faint mint `#F1F6F4`, faint pink
`#FDE0E7`) appear occasionally behind callouts or active states, but the system avoids glass/blur
effects.

---

## ICONOGRAPHY

The portfolio uses a **small inline-SVG glyph set**, not an icon font or a third-party library, and
**no emoji**. The glyphs extracted from the Figma file are: **paperclip** (case-study callout
marker), **clock** and **user** (career/role badges), and a composite **arrow** (circle outline +
shaft, used as a "go" affordance on project nav cards). **LinkedIn** and **Mail** are simple logo
glyphs in the brand link-blue circular social buttons. All glyphs are authored with `currentColor`
so they inherit color from context.

Two recurring treatments:
- **Gradient icon badge** — a 32px circle filled with the magenta→pink gradient, white glyph inside
  (`IconBadge`). Used beside callout paragraphs and in career rows.
- **Social button** — a 32px solid link-blue circle, white glyph (`SocialIcon`).

The raw extracted SVGs live in `assets/icons/` (`clip.svg`, `clock.svg`, `arrow-head.svg`,
`arrow-tail.svg`); the `Icon` component inlines them so consumers don't need file paths. When a glyph
is missing, match the existing optical weight (thin, rounded, ~18px) rather than introducing a
heavier icon set.

---

## Usage

Link the global stylesheet, load the compiled bundle, and pull components off the namespace:

```html
<link rel="stylesheet" href="styles.css" />
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, ProjectCard, SectionHeading } = window.ValeriaFilPortfolioDesignSystem_fba7d6;
</script>
```

